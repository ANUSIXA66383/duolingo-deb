[english]
this is package duolingo. 
its have lot of files duolingo.
why i choose a name duolingo? i use it.
[русский]
это пакет дуолинго 
он имеет много файлов дуолинго
почему я выбрал имя дуолинго? я использую это.

