duolingo = "duolingo"

if duolingo == "duolingo":
    print(duolingo)
else:
    print("FATAL ERROR: duolingo has no duolingo.")
    exit(-1)
def main():
    # create class duolingo
    class duolingo:
        duolingo_class = "duolingo."
    #check duolingo ==  duolingo
    if duolingo == "duolingo":
        print("duolingo has duolingo)")
    elif duolingo == "not duolingo":
        print("FATAL ERROR: DUOLINGO HAS ")
        exit(-1)
    else:
        print("FATAL ERROR: DUOLINGO HAS NO DUOLINGO")
        exit(-1)
